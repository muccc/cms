# CMS - Chaos macht Schule - Planegg 2018
Es wurden zwei Vorträge im Kupferhaus in Planegg gehalten.  

*   17 Apr. 2018 Zielgruppe Kinder und Jugendliche  
[20180417_cms_planegg_jugendforum_kids.html](./20180417_cms_planegg_jugendforum_kids.html)
*   19 Apr. 2018 Zielgruppe Eltern  
[20180419_cms_planegg_jugendforum_adults.html](./20180419_cms_planegg_jugendforum_adults.html)

## Erläutterung HTML
*   In den beiden HTML Dateien ist alles enthalten (HTML/CSS/JS)
*   Assets (Bildmaterial) befindet sich in dem Ordner **./static** und ist in dem HTML relativ verlinkt

Damit sind die beiden HTML Dateien auf jeden Webserver ohne weitere Konfiguration lauffähig.

## Beispiel Einbindung in Website
In dem ZIP Archiv befindet sich ein Beispiel für die Einbindung des Vortrages in eine bestehende Website über iFrame: [example-planegg.html](./example-planegg.html)
```
<div class="block-content">
    <!-- CCC: Beispiel für die Einbindung der Folien -->
    <iframe class="frame" width="700" height="600" style="margin-left: 50px;" src="./shells/embedder.html#../20180419_cms_planegg_jugendforum_adults.html" />
</div>
```

Für die Einbindung empfehlen wir die unter **./shells** vorhandene HTML Seite [embedder.html](./shells/embedder.html)
